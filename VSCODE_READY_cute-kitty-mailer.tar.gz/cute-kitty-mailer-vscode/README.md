# 🐱 Cute Kitty Mailer

Automated email system that sends adorable cat pictures with relaxing jazz music three times a day!

## Quick Start

1. **Setup Email**: Edit `.env` file with your Gmail credentials
2. **Install**: `npm install`
3. **Run**: `npm start`
4. **Visit**: http://localhost:3000
5. **Test**: Send yourself a test email!

## Features

- 🌅 Morning emails (8:00 AM)
- 🌤️ Afternoon emails (2:00 PM)
- 🌙 Evening emails (8:00 PM)
- 🐱 Random cat pictures from API
- 🎵 Curated jazz music playlists
- 📧 Beautiful HTML email templates
- 🎨 Time-specific color themes

## Setup Instructions

See [SETUP_GUIDE.md](SETUP_GUIDE.md) for detailed instructions.

## Technologies

- Node.js + Express
- Nodemailer (Gmail SMTP)
- node-cron (scheduling)
- EJS (templating)
- Cat as a Service API

## AI-Powered

100% generated with Claude AI (Anthropic) for AI course assignment.

---

Made with 💝 and AI
