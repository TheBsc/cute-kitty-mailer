# 🚀 Quick Reference Card

## Installation
```bash
npm install
```

## Configuration
Edit `.env`:
```env
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password
PORT=3000
```

## Run Server
```bash
npm start
```

## Access
```
http://localhost:3000
```

## Stop Server
```
Ctrl + C
```

---

## File Structure
```
cute-kitty-mailer-vscode/
├── server.js          # Main server code
├── views/
│   └── index.ejs      # Web interface
├── package.json       # Dependencies
├── .env               # Your config (EDIT THIS!)
├── README.md          # Overview
├── SETUP_GUIDE.md     # Detailed setup
└── GMAIL_SETUP.md     # Gmail App Password guide
```

---

## Important URLs

**Gmail App Password:**
https://myaccount.google.com/apppasswords

**Cat API:**
https://cataas.com/cat/cute

**Your Dashboard:**
http://localhost:3000

---

## Quick Test

1. Open http://localhost:3000
2. Scroll to "Test the Mailer"
3. Enter your email
4. Click "Send Test Email Now!"
5. Check inbox 📧

---

## Email Schedule

- 🌅 Morning: 8:00 AM
- 🌤️ Afternoon: 2:00 PM  
- 🌙 Evening: 8:00 PM

---

## APIs Used

**Cat Images:** cataas.com  
**Email:** Gmail SMTP  
**Jazz Music:** YouTube

---

## Common Commands

| Task | Command |
|------|---------|
| Install | `npm install` |
| Start | `npm start` |
| Stop | `Ctrl+C` |

---

## Troubleshooting

**Email not working?**
→ Check GMAIL_SETUP.md

**Port in use?**
→ Change PORT in .env

**Need help?**
→ Read SETUP_GUIDE.md

---

## Success Checklist

- [ ] npm install completed
- [ ] .env configured
- [ ] Server starts OK
- [ ] Can access localhost:3000
- [ ] Test email works
- [ ] Cat image in email
- [ ] Jazz link works

---

**You're all set!** 🐱🎉
